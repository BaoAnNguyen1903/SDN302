const Question = require('../model/question');
const Quiz = require('../model/quiz')

// GET /quizzes
exports.getAllQuizzes = async (req, res) => {
  const quizzes = await Quiz.find().populate('questions');
  res.json(quizzes);
};

// GET /quizzes/:quizId
exports.getQuiz = async (req, res) => {
  const quiz = await Quiz.findById(req.params.quizId).populate('questions');
  res.json(quiz);
};

// POST /quizzes
exports.createQuiz = async (req, res) => {
  const quiz = await Quiz.create(req.body);
  res.status(201).json(quiz);
};

// PUT /quizzes/:quizId
exports.updateQuiz = async (req, res) => {
  const updated = await Quiz.findByIdAndUpdate(req.params.quizId, req.body, { new: true });
  res.json(updated);
};

// DELETE /quizzes/:quizId
exports.deleteQuiz = async (req, res) => {
  await Quiz.findByIdAndDelete(req.params.quizId);
  res.sendStatus(204);
};

// GET /quizzes/:quizId/populate
exports.findQuestionsByKeyword = async (req, res) => {
  const quiz = await Quiz.findById(req.params.quizId).populate({
    path: 'questions',
    match: { keywords: 'capital' }
  });
  res.json(quiz.questions);
};

// POST /quizzes/:quizId/question
exports.addSingleQuestionToQuiz = async (req, res) => {
  const question = await Question.create(req.body);
  const quiz = await Quiz.findByIdAndUpdate(
    req.params.quizId,
    { $push: { questions: question._id } },
    { new: true }
  );
  res.json(quiz);
};

// POST /quizzes/:quizId/questions
exports.addManyQuestionsToQuiz = async (req, res) => {
  const questions = await Question.insertMany(req.body); // req.body = array of questions
  const ids = questions.map(q => q._id);
  const quiz = await Quiz.findByIdAndUpdate(
    req.params.quizId,
    { $push: { questions: { $each: ids } } },
    { new: true }
  );
  res.json(quiz);
};