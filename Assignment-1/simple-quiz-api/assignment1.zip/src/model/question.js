const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
    text: String,
    options: [String],
    keywords: [String],
    correctAnswerIndex: Number
});

const Question = mongoose.model('question', questionSchema);

module.exports = Question;
 