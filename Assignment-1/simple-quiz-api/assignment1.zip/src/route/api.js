const express = require('express');
const question = require('../controller/questionController');
const quiz = require('../controller/quizController');

const router = express.Router();

router.post('/questions', question.createQuestion);
router.get('/questions', question.getAllQuestion);
router.get('/questions/:id', question.getQuestion);
router.put('/questions/:id', question.updateQuestion);
router.delete('/questions/:id', question.deleteQuestion);

router.get('/', quiz.getAllQuizzes);
router.get('/:quizId', quiz.getQuiz);
router.post('/', quiz.createQuiz);
router.put('/:quizId', quiz.updateQuiz);
router.delete('/:quizId', quiz.deleteQuiz);

router.get('/:quizId/populate', quiz.findQuestionsByKeyword);
router.post('/:quizId/question', quiz.addSingleQuestionToQuiz);
router.post('/:quizId/questions', quiz.addManyQuestionsToQuiz);

module.exports = router;